  function CambiaPag(event) {
    event.preventDefault(); // Evita la navegación inmediata
    const nube = document.getElementById('nube');

    nube.classList.add('show'); // Activa el efecto visual

    // Espera 1 segundo (ajústalo al tiempo de la animación CSS)
    setTimeout(() => {
      window.location.href = "Simon/index.html";
    }, 1000);
  }
    function CambiaPag2(event) {
    event.preventDefault(); // Evita la navegación inmediata
    const nube = document.getElementById('nube');

    nube.classList.add('show'); // Activa el efecto visual

    // Espera 1 segundo (ajústalo al tiempo de la animación CSS)
    setTimeout(() => {
      window.location.href = "PPT/index.html";
    }, 1000);
  }
     function CambiaPag3(event) {
    event.preventDefault(); // Evita la navegación inmediata
    const nube = document.getElementById('nube');

    nube.classList.add('show'); // Activa el efecto visual

    // Espera 1 segundo (ajústalo al tiempo de la animación CSS)
    setTimeout(() => {
      window.location.href = "Tateti/index.html";
    }, 1000);
  }