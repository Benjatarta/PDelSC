// Script limpio - Base para nuevo juego
// Sistema de puntajes eliminado completamente

// Selección de elementos del DOM
const formNombres = document.getElementById("formNombres");
const inputNombre = document.getElementById("inputNombre");
const boton = document.getElementById("boton");

// Variable para el nombre del jugador
let nombreJugador = "";

// Variables para el control del video de YouTube
/**
 * Función base para iniciar el juego
 */
function iniciarJuego() {
  nombreJugador = inputNombre.value.trim();
  if (!nombreJugador) {
    // Usar validación nativa del navegador en lugar de alert
    inputNombre.reportValidity();
    return;
  }
  
  // Reproducir música de fondo
  const cancion = document.getElementById("cancion");
  cancion.play().catch(err => {
    console.warn("No se pudo reproducir el audio automáticamente:", err);
  });
  
  // Animar el formulario para que desaparezca
  formNombres.classList.add("ani");
  
  // Mostrar el contenedor del juego
  const juegoContainer = document.getElementById("juegoContainer");
  if (juegoContainer) {
    juegoContainer.style.display = "block";
  }
  
  // Mostrar y reproducir el video de YouTube
  try {
    // Esperar un poco para que el formulario termine de animarse
    setTimeout(() => {
      videoController.showAndPlayVideo();
    }, 0);
  } catch (error) {
    console.error('Error al mostrar el video:', error);
  }
  
  // Aquí puedes agregar la lógica específica del nuevo juego
  console.log(`Iniciando juego para: ${nombreJugador}`);
}

// Resto de funciones del juego Piedra, Papel o Tijeras
const choices = {
    'piedra': '<div class="piedra opcion ani2"></div>',
    'papel': '<div class="papel opcion ani2"></div>',
    'tijeras': '<div class="tijeras opcion ani2"></div>'
};

const choiceNames = {
    'piedra': 'Piedra',
    'papel': 'Papel',
    'tijeras': 'Tijeras'
};

function getComputerChoice() {
    const options = ['piedra', 'papel', 'tijeras'];
    return options[Math.floor(Math.random() * options.length)];
}

function determineWinner(userChoice, computerChoice) {
    if (userChoice === computerChoice) {
        return 'tie';
    }
    
    if (
        (userChoice === 'piedra' && computerChoice === 'tijeras') ||
        (userChoice === 'papel' && computerChoice === 'piedra') ||
        (userChoice === 'tijeras' && computerChoice === 'papel')
    ) {
        return 'win';
    } else {
        return 'lose';
    }
}

function playGame(userChoice) {
    const computerChoice = getComputerChoice();
    const result = determineWinner(userChoice, computerChoice);
    
    const resultDiv = document.getElementById('result');
    
    let resultText = '';
    let resultClass = '';
    
    switch(result) {
        case 'win':
            resultText = '¡Ganaste!';
            resultClass = 'winner';
            break;
        case 'lose':
            resultText = '¡Perdiste!';
            resultClass = 'loser';
            break;
        case 'tie':
            resultText = '¡Empate!';
            resultClass = 'tie';
            break;
    }
    
    resultDiv.innerHTML = `
        <div class="choices ani3">
            <span class="emoji">${choices[userChoice]}</span>
            <span class="vs">VS</span>
            <span class="emoji">${choices[computerChoice]}</span>
        </div>
        <div style="margin: 10px 0; font-size: 1.2em;">
            Gokú: ${choiceNames[userChoice]} | Vegeta: ${choiceNames[computerChoice]}
        </div>
        <div class="game-result ${resultClass}">
            ${resultText}
        </div>
    `;
}

/**
 * Reinicia el juego después de perder/ganar
 */
function resetearJuego(event) {
  if (event) event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show');
  
  // Espera al efecto y luego recarga la página
  setTimeout(() => {
    location.reload();
  }, 1000);
}

/**
 * Función para cambiar de página con efecto de nube
 */
function CambiaPag(event) {
  event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show');
  
  setTimeout(() => {
    window.location.href = "../index.html";
  }, 1000);
}

// Event Listeners
window.addEventListener('load', () => {
  // Habilitar validación del formulario usando required
  inputNombre.setAttribute("required", "true");
  
  // Agregar listener para la tecla Enter en el formulario
  formNombres.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      iniciarJuego();
    }
  });
});

// Botón para iniciar el juego
boton.addEventListener("click", iniciarJuego);