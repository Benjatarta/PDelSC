export class Alfajor{
    constructor (nombre, marca, peso, valor){
        this.nombre = nombre;
        this.marca = marca;
        this.peso = peso;
        this._precio = valor;
    }
    get precio(){
        return this._precio;
    }
    set precio( nuevo_precio){
        let numero = parseInt(nuevo_precio);
        if(isNaN(numero)==true){
            console.log("No es un numero");    
        }
        else{
            this._precio = `$${numero}`;
        }
    }
    mostrar (){
        console.log(`El nuevo ${this.nombre} de ${this.marca}, con un peso de ${this.peso} y su valor es de ${this._precio}`);
    }
};