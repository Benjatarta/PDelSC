export class estudiante{
    constructor (nombre, apellido, edad){
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    saludar(){
        console.log(`Hola tengo ${this.nombre} ${this.apellido} ${this.edad}`);
    }
};