import { estudiante } from "./estudiante.js";
import { Alfajor } from "./alfajor.js";
let alumno = new estudiante ("Un", "Hombro", "Menos");
let alfa = new Alfajor ("Alfajor de almendras", "Valeria Patissiere", "125gr", "$2500");
alumno.saludar();
alfa.mostrar();
alfa.precio = 100;
alfa.mostrar();

