// Array para almacenar las letras de la palabra
let palabraArray = [];

// Formulario de palabra
const formularioPalabra = document.getElementById('formularioPalabra');
const inputPalabra = document.getElementById('inputPalabra');
const palabraModificada = document.getElementById('palabraModificada');

// Función para modificar la palabra (eliminar 2 letras desde la posición 1)
function modificarPalabra() {
    // Verificar que el array tenga más de 2 letras
    if (palabraArray.length > 1) {
        palabraArray.splice(1, 2);  // Eliminar dos letras desde la posición 1
        palabraModificada.textContent = palabraArray.join('');  // Mostrar la palabra modificada
    } else {
        palabraModificada.textContent = "No hay suficientes letras para eliminar.";
    }
}

// Evento del formulario (cuando el usuario envíe el formulario)
formularioPalabra.addEventListener('submit', function(event) {
    event.preventDefault(); // Evitar que la página se recargue

    // Obtener la palabra del input
    const palabra = inputPalabra.value.trim();

    if (palabra) {
        // Convertir la palabra en un array de letras
        palabraArray = palabra.split('');

        // Llamar a la función para modificar la palabra
        modificarPalabra();
    } else {
        alert("Por favor, ingresa una palabra.");
    }
});
