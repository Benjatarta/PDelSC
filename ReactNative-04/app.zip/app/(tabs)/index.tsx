import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  Image, 
  TextInput, 
  Pressable, 
  ScrollView, 
  Switch, 
  FlatList, 
  SectionList, 
  ActivityIndicator,
  TouchableOpacity
} from 'react-native';

export default function HomeScreen() {
  const [text, onChangeText] = useState('');
  const [isEnabled, setIsEnabled] = useState(false);
  const [loading, setLoading] = useState(false);

  const toggleSwitch = () => setIsEnabled(prev => !prev);

  const [buttonColor, setButtonColor] = useState('white');
  const getRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  const data = [
    {id: '1', title: 'Manzana'},
    {id: '2', title: 'Banana'},
    {id: '3', title: 'Naranja'},
  ];

  return (
    <ScrollView style={{flex:1}}>
      <Text style={styles.titulo}>Componentes nativos</Text>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>Text</Text>
        <Text style={styles.textEjemplo}>¡Hola, soy Goku!</Text>
        <Text style={styles.descripcion}>
          Sirve para mostrar texto en pantalla
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>Image</Text>
        <Image style={styles.imagen}
          source={{
            uri: 'https://i.pinimg.com/originals/31/ba/55/31ba55c416217e9d48b1b37bf7023e81.jpg',
          }}
        />
        <Text style={styles.descripcion}>
          Muestra imágenes desde una URL o locales
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>TextInput</Text>
        <TextInput
          style={styles.input}
          placeholder="Escribí algo..."
          onChangeText={onChangeText}
          value={text}
        />
        <Text style={styles.descripcion}>
          Campo de texto editable
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>Pressable</Text>
        <Pressable
          onPress={() => {setButtonColor(getRandomColor());}}
          style={({pressed}) => [
            {
              backgroundColor: pressed ? 'rgb(210, 230, 255)' : buttonColor,
            },
            styles.wrapperCustom,
          ]}>
          <Text style={styles.text}>Presioname</Text>
        </Pressable>
        <Text style={styles.descripcion}>
          Es un contenedor que detecta interacciones
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>Switch</Text>
        <View style={styles.switchContainer}>
          <Switch
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"}
            onValueChange={toggleSwitch}
            value={isEnabled}
          />
        </View>
        <Text style={styles.descripcion}>
          Switch de encendido/apagado.
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>FlatList</Text>
        <FlatList
          data={data}
          renderItem={({item}) => <Text style={styles.lista}>{item.title}</Text>}
          keyExtractor={item => item.id}
        />
        <Text style={styles.descripcion}>
          Lista básica para cargar datos
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.subtitulo}>ActivityIndicator</Text>
        <TouchableOpacity onPress={() => setLoading(!loading)} style={styles.wrapperCustom}>
          <Text style={styles.text}>Cargar</Text>
        </TouchableOpacity>
        {loading && <ActivityIndicator size="large" color="#00ff00" />}
        <Text style={styles.descripcion}>
          Indicador de carga 
        </Text>
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  titulo: {
    fontSize: 35,
    color: 'black',
    textAlign: 'center',
    marginTop: 20,
  },
  subtitulo: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  card: {
    borderWidth: 2,
    borderColor: 'black',
    borderRadius: 15,
    margin: 15,
    padding: 15,
    backgroundColor: '#f9f9f9',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    alignSelf: 'center',    
    maxWidth: 600,
  },
  textEjemplo: {
    fontSize: 20,
    textAlign: 'center',
    marginVertical: 10,
  },
  descripcion: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
  input: {
    height: 60,
    width: 250,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    alignSelf: 'center',
    textAlign: 'center',
    fontSize: 20,
    borderRadius: 15,
  },
  imagen: {
    width: 250,
    height: 250,
    borderRadius: 20,
    alignSelf: 'center',
  },
  text: {
    fontSize: 20,
    textAlign: 'center',
  },
  wrapperCustom: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderRadius: 20,
    padding: 10,
    borderWidth: 1,
    width: 200,
    height: 60,
    borderColor: '#000',
    marginBottom: 10,
  },
  switchContainer: {
    alignSelf: 'center',
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 15,
    padding: 10,
    backgroundColor: '#eee',
  },
  lista: {
    fontSize: 18,
    padding: 5,
    textAlign: 'center',
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 10,
    textAlign: 'center',
  },
});
