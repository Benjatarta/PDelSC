function texto(){
    const info = getElementById("text");
    if (info.style.display === "none") {
        info.style.display = "block";
      } else {
        info.style.display = "none";
      }
}