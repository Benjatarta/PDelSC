import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Pagina1 from './components/pagina1';
import Pagina2 from './components/pagina2';
import Pagina3 from './components/pagina3';
import { TareasProvider } from './components/tareas';
function App() {
  return (
    <TareasProvider>
      <Router>
        <div className="container mt-4">
          <Routes>
            <Route path="/" element={<Pagina1 />} />
            <Route path="/detalle/:id" element={<Pagina2 />} />
            <Route path="/crear" element={<Pagina3 />} />
          </Routes>
        </div>
      </Router>
    </TareasProvider>
  );
}

export default App;
