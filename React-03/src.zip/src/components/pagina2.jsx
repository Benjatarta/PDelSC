import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useTareas } from './tareas';

// creo la funcion para ver los detalles
function Pagina2() {
  const { id } = useParams(); 
  const { tareas } = useTareas();
  const tarea = tareas.find((tarea) => tarea.id === parseInt(id));

  // constante para saber la fecha del dia
  const fechaCreacion = new Date(tarea.id).toLocaleDateString(); 

  //creo el html
  return (
    <>
      <h2>Detalles de la tarea</h2>
      <h3>{tarea.titulo}</h3>
      <p>{tarea.descripcion}</p>
      <p><strong>Estado:</strong> {tarea.completa ? 'Completada' : 'Incompleta'}</p>
      <p><strong>Fecha de creación:</strong> {fechaCreacion}</p>
      <Link to="/" className="btn btn-secondary">Volver</Link>
    </>
  );
}

export default Pagina2;
