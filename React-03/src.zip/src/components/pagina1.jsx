import React from 'react';
import { Link } from 'react-router-dom';
import { useTareas } from './tareas';

function Pagina1() {
    const { tareas, eliminarTarea } = useTareas();
    //creo la constante para que haya una breve descripcion
    const breveDescripcion = (descripcion, maxLength = 10) => {
        if (descripcion.length <= maxLength) return descripcion;
        return descripcion.substring(0, maxLength) + '...';
    };

    //creo la funcion para descargar la lista de tareas
    const descargarTareas = () => {
        const tareasJson = JSON.stringify(tareas, null, 2);
        const blob = new Blob([tareasJson], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const enlace = document.createElement('a');
        enlace.href = url;
        enlace.download = 'tareas.json';
        enlace.click();
        URL.revokeObjectURL(url);
    };

    //creo la funcion para eliminar la tarea
    const handleEliminar = (id) => {
            eliminarTarea(id); 
    };

    return (
        <>
            <h1>Lista de Tareas</h1>
            <Link to="/crear" className="btn btn-primary mb-3">Crear tarea</Link>
            <button onClick={descargarTareas} className="btn btn-secondary mb-3">Descargar tareas</button>
            <ul className="list-group">
                {tareas.length > 0 ? (
                    tareas.map((tarea) => (
                        <li key={tarea.id} className="list-group-item">
                            <h5>{tarea.titulo}</h5>
                            <p>{breveDescripcion(tarea.descripcion)}</p>
                            <Link to={`/detalle/${tarea.id}`} className="btn btn-outline-info me-2">Detalles</Link>
                            <button 
                                onClick={() => handleEliminar(tarea.id)} 
                                className="btn btn-outline-danger">Eliminar
                            </button>
                        </li>
                    ))
                ) : (
                    <li className="list-group-item">No hay tareas creadas</li>
                )}
            </ul>
        </>
    );
}

export default Pagina1;
