import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTareas } from './tareas'; 

//creo la funcion para crear la tarea
function Pagina3() {
    const [titulo, setTitulo] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const [completa, setCompleta] = useState(false); 
    const { agregarTarea } = useTareas();
    //creo la constante navigate, para mandar la tarea al listado 
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();
        const nuevaTarea = {
            id: Date.now(),
            titulo,
            descripcion,
            completa, 
        };
        agregarTarea(nuevaTarea); 
        navigate('/'); 
    };
//creo el html
    return (
        <>
            <h2>Crear tarea</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Título</label>
                    <input 
                        type="text" 
                        className="form-control" 
                        value={titulo} 
                        onChange={(event) => setTitulo(event.target.value)}  
                        required 
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Descripción</label>
                    <textarea 
                        className="form-control" 
                        value={descripcion} 
                        onChange={(event) => setDescripcion(event.target.value)} 
                        required 
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Estado de la tarea</label>
                    <div>
                        <label className="form-check-label me-3">
                            <input 
                                type="radio" 
                                name="estado" 
                                value="completa" 
                                checked={completa === true} 
                                onChange={() => setCompleta(true)} 
                                className="form-check-input" 
                            />
                            Completa
                        </label>
                        <label className="form-check-label">
                            <input 
                                type="radio" 
                                name="estado" 
                                value="incompleta" 
                                checked={completa === false} 
                                onChange={() => setCompleta(false)} 
                                className="form-check-input" 
                            />
                            Incompleta
                        </label>
                    </div>
                </div>
                <button type="submit" className="btn btn-success">Crear tarea</button>
            </form>
        </>
    );
}

export default Pagina3;
