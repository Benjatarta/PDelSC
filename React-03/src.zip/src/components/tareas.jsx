import React, { createContext, useState, useContext } from 'react';
const TareaEstado = createContext();

export function TareasProvider({ children }) {
  const [tareas, setTareas] = useState([]);

  const agregarTarea = (tarea) => {
    setTareas((prevTareas) => [...prevTareas, tarea]);
  };
  const eliminarTarea = (id) => {
    setTareas((prevTareas) => prevTareas.filter((tarea) => tarea.id !== id));
};

  return (
    <TareaEstado.Provider value={{ tareas, agregarTarea, eliminarTarea}}>
      {children}
    </TareaEstado.Provider>
  );
}
export function useTareas() {
  return useContext(TareaEstado );
}
