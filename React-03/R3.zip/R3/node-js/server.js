const express = require('express');
const cors = require('cors');
const connectDb = require('./connectbdd'); // O como se llame tu archivo de conexión

const app = express();
app.use(express.json()); // Permite a Express leer JSON en el cuerpo de las peticiones
app.use(cors()); // Habilita CORS para permitir peticiones desde React

// Endpoint para obtener todos los usuarios
app.get('/usuarios', async (req, res) => {
  const db = await connectDb();
  if (!db) {
    return res.status(500).json({ error: 'No se pudo conectar a la base de datos' });
  }
  try {
    const [rows] = await db.execute('SELECT * FROM usr');
    res.status(200).json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener usuarios' });
  } finally {
    if (db) db.end();
  }
});

// Endpoint para crear un nuevo usuario
app.post('/usuarios', async (req, res) => {
  const { Nombre, Apellido, Direccion, Telefono, Celular, FechaDeNacimiento, Email } = req.body;
  const db = await connectDb();
  if (!db) {
    return res.status(500).json({ error: 'No se pudo conectar a la base de datos' });
  }
  try {
    const [result] = await db.execute(
      'INSERT INTO usr (Nombre, Apellido, Direccion, Telefono, Celular, FechaDeNacimiento, Email) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [Nombre, Apellido, Direccion, Telefono, Celular, FechaDeNacimiento, Email]
    );
    res.status(201).json({ message: 'Usuario creado', id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Error al crear usuario' });
  } finally {
    if (db) db.end();
  }
});

// Otros endpoints para actualizar y eliminar...

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor escuchando en el puerto ${PORT}`);
});