import { connectDb } from './connectbbdd.js';


const main = async () => {
    const db = await connectDb();
    if(!db) {
        console.log("No se pudo acceder a la conexión");
        return;}
    const [rows] = await db.execute('SELECT * FROM tablita');
    console.log (rows);
    await db.end();
}
main();