// index.js (dentro de la carpeta node-js)

// Importa los módulos necesarios
import express from 'express';
import cors from 'cors';
import { connectDb } from './connectbbdd.js';

// Crea una instancia de la aplicación Express
const app = express();

// Middlewares (código que se ejecuta antes de las rutas)
app.use(express.json()); // Permite que la API lea datos en formato JSON
app.use(cors()); // Permite peticiones desde tu aplicación React

// Puerto en el que se ejecutará el servidor
const PORT = 3001;

// Rutas de la API (Endpoints)

// 1. Ruta para OBTENER todos los usuarios (GET)
app.get('/usuarios', async (req, res) => {
  const db = await connectDb();
  if (!db) {
    return res.status(500).json({ error: 'No se pudo conectar a la base de datos' });
  }
  try {
    const [rows] = await db.execute('SELECT * FROM tablita');
    res.json(rows);
  } catch (error) {
    console.error('Error al obtener los usuarios:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  } finally {
    if (db) await db.end();
  }
});

// 2. Ruta para CREAR un nuevo usuario (POST)
app.post('/usuarios', async (req, res) => {
  const { Nombre, Apellido, Direccion, Telefono, Celular, Fecha_de_nacimiento, Email } = req.body;
  const db = await connectDb();
  if (!db) {
    return res.status(500).json({ error: 'No se pudo conectar a la base de datos' });
  }
  try {
    const query = 'INSERT INTO tablita (Nombre, Apellido, Direccion, Telefono, Celular, Fecha_de_nacimiento, Email) VALUES (?, ?, ?, ?, ?, ?, ?)';
    const values = [Nombre, Apellido, Direccion, Telefono, Celular, Fecha_de_nacimiento, Email];
    const [result] = await db.execute(query, values);
    res.status(201).json({ message: 'Usuario creado exitosamente', id: result.insertId });
  } catch (error) {
    console.error('Error al crear el usuario:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  } finally {
    if (db) await db.end();
  }
});

// 3. Ruta para ACTUALIZAR un usuario (PUT)
app.put('/usuarios/:id', async (req, res) => {
  const { id } = req.params;
  const { Nombre, Apellido, Direccion, Telefono, Celular, Fecha_de_nacimiento, Email } = req.body;
  const db = await connectDb();
  if (!db) {
    return res.status(500).json({ error: 'No se pudo conectar a la base de datos' });
  }
  try {
    const query = 'UPDATE tablita SET Nombre = ?, Apellido = ?, Direccion = ?, Telefono = ?, Celular = ?, Fecha_de_nacimiento = ?, Email = ? WHERE id = ?';
    const values = [Nombre, Apellido, Direccion, Telefono, Celular, Fecha_de_nacimiento, Email, id];
    await db.execute(query, values);
    res.json({ message: 'Usuario actualizado exitosamente' });
  } catch (error) {
    console.error('Error al actualizar el usuario:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  } finally {
    if (db) await db.end();
  }
});

// 4. Ruta para ELIMINAR un usuario (DELETE)
app.delete('/usuarios/:id', async (req, res) => {
  const { id } = req.params;
  const db = await connectDb();
  if (!db) {
    return res.status(500).json({ error: 'No se pudo conectar a la base de datos' });
  }
  try {
    const [result] = await db.execute('DELETE FROM tablita WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado.' });
    }
    res.json({ message: 'Usuario eliminado exitosamente' });
  } catch (error) {
    console.error('Error al eliminar el usuario:', error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  } finally {
    if (db) await db.end();
  }
});

// Inicia el servidor para que empiece a escuchar peticiones
app.listen(PORT, () => {
  console.log(`Servidor de la API escuchando en http://localhost:${PORT}`);
});