import  mysql from 'mysql2/promise';
export async function connectDb (){
    try{
        const connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '',
            database: 'usuarios'
        });
        console.log ('Conexión establecida');
        return connection;
    } catch(err){
        console.log('Error de conexión', err);
    }
    
}