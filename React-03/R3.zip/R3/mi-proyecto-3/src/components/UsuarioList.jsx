import React from 'react';

function UsuarioList({ usuarios, onEdit, onDelete }) {
  if (usuarios.length === 0) {
    return <p>No hay usuarios registrados.</p>;
  }

  return (
    <div>
      <h2>Lista de Usuarios</h2>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {usuarios.map(usuario => (
            <tr key={usuario.id}>
              <td>{usuario.Nombre}</td>
              <td>{usuario.Apellido}</td>
              <td>{usuario.Email}</td>
              <td>
                <button onClick={() => onEdit(usuario)}>Editar</button>
                <button onClick={() => onDelete(usuario.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default UsuarioList;