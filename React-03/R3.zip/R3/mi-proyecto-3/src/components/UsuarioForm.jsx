import React, { useState, useEffect } from 'react';

const emptyForm = {
  Nombre: '',
  Apellido: '',
  Direccion: '',
  Telefono: '',
  Celular: '',
  Fecha_de_nacimiento: '',
  Email: '',
};

function UsuarioForm({ onSave, usuarioToEdit }) {
  const [formData, setFormData] = useState(emptyForm);
  const isEditing = !!usuarioToEdit;

  // Si hay un usuario para editar, llena el formulario con sus datos
  useEffect(() => {
    if (isEditing) {
      setFormData(usuarioToEdit);
    } else {
      setFormData(emptyForm);
    }
  }, [usuarioToEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    setFormData(emptyForm); // Limpia el formulario después de guardar
  };

  return (
    <div>
      <h2>{isEditing ? 'Editar Usuario' : 'Crear Nuevo Usuario'}</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="Nombre" value={formData.Nombre} onChange={handleChange} placeholder="Nombre" required />
        <input type="text" name="Apellido" value={formData.Apellido} onChange={handleChange} placeholder="Apellido" required />
        <input type="text" name="Direccion" value={formData.Direccion} onChange={handleChange} placeholder="Dirección" />
        <input type="text" name="Telefono" value={formData.Telefono} onChange={handleChange} placeholder="Teléfono" />
        <input type="text" name="Celular" value={formData.Celular} onChange={handleChange} placeholder="Celular" />
        <input type="date" name="Fecha_de_nacimiento" value={formData.Fecha_de_nacimiento} onChange={handleChange} placeholder="Fecha de Nacimiento" />
        <input type="email" name="Email" value={formData.Email} onChange={handleChange} placeholder="Email" required />
        <button type="submit">{isEditing ? 'Actualizar' : 'Crear'}</button>
        {isEditing && <button type="button" onClick={() => onSave(null)}>Cancelar</button>}
      </form>
    </div>
  );
}

export default UsuarioForm;