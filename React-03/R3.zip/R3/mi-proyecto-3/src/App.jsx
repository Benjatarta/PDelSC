import React, { useState, useEffect } from 'react';
import axios from 'axios';
import UsuarioList from './components/UsuarioList.jsx';
import UsuarioForm from './components/UsuarioForm.jsx';
import './App.css';

// URL de tu API de Node.js
const API_URL = 'http://localhost:3001/usuarios';

const handleSaveUsuario = async (usuario) => {
  try {
    if (selectedUsuario) {
      // Actualizar usuario existente (PUT)
      await axios.put(`${API_URL}/${usuario.id}`, usuario);
    } else {
      // Crear nuevo usuario (POST)
      await axios.post(API_URL, usuario);
    }
    // Limpia el estado de edición
    setSelectedUsuario(null);
    // 💡 Este es el paso clave: Vuelve a buscar los usuarios después de guardar.
    fetchUsuarios();
  } catch (error) {
    console.error("Error al guardar el usuario:", error);
  }
};
function App() {
  const [usuarios, setUsuarios] = useState([]);
  const [selectedUsuario, setSelectedUsuario] = useState(null);

  // Función para obtener todos los usuarios de la API
  const fetchUsuarios = async () => {
    try {
      const response = await axios.get(API_URL);
      setUsuarios(response.data);
    } catch (error) {
      console.error("Error al obtener los usuarios:", error);
    }
  };

  // Carga los usuarios cuando el componente se monta por primera vez
  useEffect(() => {
    fetchUsuarios();
  }, []);

  // Función para agregar o actualizar un usuario
  const handleSaveUsuario = async (usuario) => {
    try {
      if (selectedUsuario) {
        // Actualizar usuario existente (PUT)
        await axios.put(`${API_URL}/${usuario.id}`, usuario);
      } else {
        // Crear nuevo usuario (POST)
        await axios.post(API_URL, usuario);
      }
      // Limpia el estado de edición y recarga la lista de usuarios
      setSelectedUsuario(null);
      fetchUsuarios();
    } catch (error) {
      console.error("Error al guardar el usuario:", error);
    }
  };

  // Función para eliminar un usuario
  const handleDeleteUsuario = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      fetchUsuarios();
    } catch (error) {
      console.error("Error al eliminar el usuario:", error);
    }
  };

  return (
    <div className="container">
      <h1>Gestión de Usuarios</h1>
      <UsuarioForm
        onSave={handleSaveUsuario}
        usuarioToEdit={selectedUsuario}
      />
      <hr />
      <UsuarioList
        usuarios={usuarios}
        onEdit={setSelectedUsuario}
        onDelete={handleDeleteUsuario}
      />
    </div>
  );
}

export default App;